-- MySQL dump 10.10
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	5.0.22-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `EpoComputerProperties`
--

DROP TABLE IF EXISTS `EpoComputerProperties`;
CREATE TABLE `EpoComputerProperties` (
  `id` int(11) NOT NULL auto_increment,
  `sid` int(11) NOT NULL,
  `LastUpdate` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `ParentID` int(11) NOT NULL,
  `ComputerName` varchar(255) NOT NULL,
  `DomainName` varchar(100) default NULL,
  `IPAddress` varchar(100) default NULL,
  `OSType` varchar(100) default NULL,
  `OSVersion` varchar(100) default NULL,
  `OSServicePackVer` varchar(100) default NULL,
  `OSBuildNum` smallint(6) default NULL,
  `NetAddress` varchar(100) NOT NULL,
  `UserName` varchar(128) default NULL,
  `IPHostName` varchar(255) default NULL,
  `TheTimestamp` binary(8) default NULL,
  `AgentVersion` varchar(50) default NULL COMMENT 'epo agent version',
  `LastDATUpdate` timestamp NOT NULL default '0000-00-00 00:00:00' COMMENT 'date/time when DAT file was updated',
  `DATVersion` varchar(20) default NULL COMMENT 'Version of the DAT file',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `sid` (`sid`),
  UNIQUE KEY `Alter_Key4` (`sid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

--
-- Table structure for table `auth_profile`
--

DROP TABLE IF EXISTS `auth_profile`;
CREATE TABLE `auth_profile` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `method` varchar(16) NOT NULL COMMENT 'access config : static, vmps, 8021x',
  `config` text COMMENT 'optionnal : configuration instructions ',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

--
-- Table structure for table `building`
--

DROP TABLE IF EXISTS `building`;
CREATE TABLE `building` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(64) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

--
-- Table structure for table `cabletype`
--

DROP TABLE IF EXISTS `cabletype`;
CREATE TABLE `cabletype` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(64) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `config`
--

DROP TABLE IF EXISTS `config`;
CREATE TABLE `config` (
  `id` int(11) NOT NULL auto_increment,
  `type` varchar(16) default NULL,
  `name` varchar(64) default NULL,
  `value` varchar(255) default NULL,
  `comment` varchar(255) default NULL,
  `LastChange` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `who` int(11) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `name_2` (`name`),
  UNIQUE KEY `name_3` (`name`),
  UNIQUE KEY `name_4` (`name`),
  UNIQUE KEY `name_5` (`name`),
  UNIQUE KEY `name_6` (`name`),
  KEY `who` (`who`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `dhcp_options`
--

DROP TABLE IF EXISTS `dhcp_options`;
CREATE TABLE `dhcp_options` (
  `id` int(11) NOT NULL auto_increment,
  `scope` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `value` varchar(256) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `scope` (`scope`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

--
-- Table structure for table `dhcp_subnets`
--

DROP TABLE IF EXISTS `dhcp_subnets`;
CREATE TABLE `dhcp_subnets` (
  `id` int(11) NOT NULL auto_increment,
  `subnet_id` int(11) NOT NULL,
  `dhcp_from` varchar(15) NOT NULL,
  `dhcp_to` varchar(15) NOT NULL,
  `dhcp_defaultrouter` varchar(128) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `subnet_id` (`subnet_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

--
-- Table structure for table `epo_systems`
--

DROP TABLE IF EXISTS `epo_systems`;
CREATE TABLE `epo_systems` (
  `sid` int(11) NOT NULL,
  `nodename` varchar(30) default NULL,
  `domainname` varchar(100) default NULL,
  `ip` varchar(20) default NULL,
  `mac` varchar(30) NOT NULL,
  `agentversion` varchar(50) default NULL,
  `lastepocontact` datetime default NULL,
  `virusver` varchar(50) default NULL,
  `virusenginever` varchar(100) default NULL,
  `virusdatver` varchar(50) default NULL,
  `virushotfix` varchar(100) default NULL,
  `ostype` varchar(100) default NULL,
  `osversion` varchar(100) default NULL,
  `osservicepackver` varchar(100) default NULL,
  `osbuildnum` int(11) default NULL,
  `freediskspace` int(11) default NULL,
  `username` varchar(128) default NULL,
  `lastsync` datetime NOT NULL,
  PRIMARY KEY  (`sid`),
  UNIQUE KEY `sid` (`sid`),
  UNIQUE KEY `mac` (`mac`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='list of systems with the epo client installed, synced from e';

--
-- Table structure for table `epo_versions`
--

DROP TABLE IF EXISTS `epo_versions`;
CREATE TABLE `epo_versions` (
  `id` int(11) NOT NULL auto_increment,
  `product` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `hotfix` varchar(32) default NULL,
  `lastsync` datetime NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='current version of epo products, synced from epo database';

--
-- Table structure for table `ethernet`
--

DROP TABLE IF EXISTS `ethernet`;
CREATE TABLE `ethernet` (
  `vendor` varchar(16) NOT NULL,
  `mac` varchar(6) NOT NULL,
  PRIMARY KEY  (`mac`),
  UNIQUE KEY `mac` (`mac`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

--
-- Table structure for table `guilog`
--

DROP TABLE IF EXISTS `guilog`;
CREATE TABLE `guilog` (
  `who` int(11) NOT NULL,
  `host` varchar(20) NOT NULL,
  `datetime` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `priority` enum('info','err','crit') default 'info',
  `what` varchar(200) NOT NULL,
  `id` bigint(20) unsigned NOT NULL auto_increment,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `who` (`who`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

--
-- Table structure for table `guirights`
--

DROP TABLE IF EXISTS `guirights`;
CREATE TABLE `guirights` (
  `code` int(11) NOT NULL default '0',
  `value` varchar(30) NOT NULL,
  `ad_group` varchar(255) NOT NULL,
  PRIMARY KEY  (`code`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

--
-- Table structure for table `health`
--

DROP TABLE IF EXISTS `health`;
CREATE TABLE `health` (
  `id` int(10) unsigned NOT NULL,
  `value` varchar(30) NOT NULL,
  `color` varchar(6) default NULL,
  `comment` varchar(100) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `location`
--

DROP TABLE IF EXISTS `location`;
CREATE TABLE `location` (
  `id` int(15) NOT NULL auto_increment,
  `building_id` int(11) NOT NULL default '1',
  `name` varchar(64) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `building_id` (`building_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

--
-- Table structure for table `nac_hostscanned`
--

DROP TABLE IF EXISTS `nac_hostscanned`;
CREATE TABLE `nac_hostscanned` (
  `sid` int(11) NOT NULL,
  `id` int(10) unsigned NOT NULL auto_increment,
  `ip` varchar(15) NOT NULL,
  `hostname` varchar(80) default NULL,
  `os` varchar(80) default NULL,
  `timestamp` datetime default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `sid` (`sid`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

--
-- Table structure for table `nac_openports`
--

DROP TABLE IF EXISTS `nac_openports`;
CREATE TABLE `nac_openports` (
  `id` int(11) NOT NULL auto_increment,
  `sid` int(10) NOT NULL,
  `service` int(11) NOT NULL,
  `banner` varchar(128) default NULL,
  `timestamp` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `service` (`service`),
  KEY `sid` (`sid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

--
-- Table structure for table `naclog`
--

DROP TABLE IF EXISTS `naclog`;
CREATE TABLE `naclog` (
  `who` int(11) NOT NULL,
  `host` varchar(30) default NULL,
  `datetime` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `priority` enum('info','err','crit') default 'info',
  `what` varchar(200) default NULL,
  `id` bigint(20) unsigned NOT NULL auto_increment,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `who` (`who`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Log of server activities';

--
-- Table structure for table `oper`
--

DROP TABLE IF EXISTS `oper`;
CREATE TABLE `oper` (
  `value` enum('guiupdate','vmpsupdate','vmpscheck','server1','server2','lastseen1','lastseen2') NOT NULL default 'guiupdate',
  `datetime` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `comment` varchar(66) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Status of GUI and daemons';

--
-- Table structure for table `patchcable`
--

DROP TABLE IF EXISTS `patchcable`;
CREATE TABLE `patchcable` (
  `id` int(11) NOT NULL auto_increment,
  `rack` varchar(30) NOT NULL,
  `rack_location` varchar(30) NOT NULL,
  `outlet` varchar(30) NOT NULL,
  `other` varchar(30) NOT NULL,
  `office` int(11) NOT NULL default '1',
  `type` int(11) NOT NULL default '0',
  `port` int(11) NOT NULL,
  `comment` varchar(255) NOT NULL,
  `lastchange` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `modifiedby` int(11) NOT NULL,
  `expiry` date default NULL,
  PRIMARY KEY  (`id`),
  KEY `office` (`office`),
  KEY `port` (`port`),
  KEY `modifiedby` (`modifiedby`),
  KEY `type` (`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Patch cables from Office Sockets to Port Switches';

--
-- Table structure for table `port`
--

DROP TABLE IF EXISTS `port`;
CREATE TABLE `port` (
  `id` int(11) NOT NULL auto_increment,
  `switch` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `comment` varchar(255) default NULL,
  `restart_now` int(11) default '0',
  `default_vlan` int(11) default '0',
  `snmp_idx` int(11) default NULL,
  `last_vlan` int(11) default '0',
  `last_activity` datetime default NULL,
  `auth_profile` int(11) unsigned default '0',
  `last_monitored` datetime default NULL COMMENT 'Last time the port was monitored',
  `up` int(11) default NULL COMMENT 'Monitor: port is up(1) or down?',
  `shutdown` int(11) default '0',
  `last_auth_profile` int(11) default NULL COMMENT 'Is port static/dynamic? (lookup table auth_profile)',
  `staticvlan` int(11) default NULL COMMENT 'If auth_profile is static, program to this vlan index',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `Alter_Key2` (`switch`,`name`),
  KEY `auth_profile` (`auth_profile`),
  KEY `default_vlan` (`default_vlan`),
  KEY `last_vlan` (`last_vlan`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

--
-- Table structure for table `protocols`
--

DROP TABLE IF EXISTS `protocols`;
CREATE TABLE `protocols` (
  `protocol` int(11) NOT NULL default '0',
  `name` varchar(50) default NULL,
  `description` varchar(50) default NULL,
  PRIMARY KEY  (`protocol`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

--
-- Table structure for table `services`
--

DROP TABLE IF EXISTS `services`;
CREATE TABLE `services` (
  `id` int(11) NOT NULL auto_increment,
  `port` int(11) NOT NULL,
  `protocol` int(11) NOT NULL default '6',
  `name` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `protocol` (`protocol`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

--
-- Table structure for table `stat_ports`
--

DROP TABLE IF EXISTS `stat_ports`;
CREATE TABLE `stat_ports` (
  `date` date NOT NULL default '0000-00-00',
  `auth_profile` int(11) unsigned NOT NULL default '0',
  `count` int(11) default NULL,
  KEY `auth_profile` (`auth_profile`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;

--
-- Table structure for table `stat_systems`
--

DROP TABLE IF EXISTS `stat_systems`;
CREATE TABLE `stat_systems` (
  `date` date NOT NULL default '0000-00-00',
  `vstatus` int(10) unsigned NOT NULL,
  `count` int(11) default NULL,
  KEY `vstatus` (`vstatus`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;

--
-- Table structure for table `stats`
--

DROP TABLE IF EXISTS `stats`;
CREATE TABLE `stats` (
  `id` int(11) NOT NULL auto_increment,
  `code` varchar(100) default NULL,
  `value` int(11) NOT NULL,
  `datetime` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Table structure for table `subnets`
--

DROP TABLE IF EXISTS `subnets`;
CREATE TABLE `subnets` (
  `id` int(11) NOT NULL auto_increment,
  `ip_address` varchar(20) NOT NULL,
  `ip_netmask` int(4) NOT NULL,
  `scan` tinyint(4) NOT NULL,
  `dontscan` varchar(128) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

--
-- Table structure for table `switch`
--

DROP TABLE IF EXISTS `switch`;
CREATE TABLE `switch` (
  `id` int(11) NOT NULL auto_increment,
  `ip` varchar(20) NOT NULL default 'NULL',
  `name` varchar(20) default 'NULL',
  `location` int(11) default '1',
  `comment` varchar(50) default 'NULL',
  `swgroup` varchar(20) default 'NULL',
  `notify` varchar(200) default 'NULL',
  `ap` tinyint(4) default '0',
  `scan` tinyint(1) default '0',
  `hw` char(64) default NULL,
  `sw` char(64) default NULL,
  `last_monitored` datetime default NULL COMMENT 'Last time the switch was polled',
  `up` int(11) default NULL COMMENT 'Monitor: switch is reachable(1) or down?',
  `vlan_id` int(11) default '0',
  `scan3` tinyint(1) default '0',
  `switch_type` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `location` (`location`),
  KEY `switch_type` (`switch_type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

--
-- Table structure for table `sys_class`
--

DROP TABLE IF EXISTS `sys_class`;
CREATE TABLE `sys_class` (
  `id` int(10) unsigned NOT NULL auto_increment COMMENT 'Unique Number',
  `value` varchar(30) NOT NULL COMMENT 'Class lookup for systems',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Device Types';

--
-- Table structure for table `sys_class2`
--

DROP TABLE IF EXISTS `sys_class2`;
CREATE TABLE `sys_class2` (
  `id` int(10) unsigned NOT NULL auto_increment COMMENT 'Unique Number',
  `value` varchar(30) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

--
-- Table structure for table `sys_os`
--

DROP TABLE IF EXISTS `sys_os`;
CREATE TABLE `sys_os` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `value` varchar(30) NOT NULL COMMENT 'Operating System lookup for systems',
  `icon` varchar(20) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

--
-- Table structure for table `sys_os1`
--

DROP TABLE IF EXISTS `sys_os1`;
CREATE TABLE `sys_os1` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `value` varchar(30) NOT NULL COMMENT 'Operating System lookup for systems',
  `icon` varchar(20) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

--
-- Table structure for table `sys_os2`
--

DROP TABLE IF EXISTS `sys_os2`;
CREATE TABLE `sys_os2` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `value` varchar(30) NOT NULL COMMENT 'Operating System lookup for systems',
  `icon` varchar(20) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

--
-- Table structure for table `sys_os3`
--

DROP TABLE IF EXISTS `sys_os3`;
CREATE TABLE `sys_os3` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `value` varchar(30) NOT NULL COMMENT 'Operating System lookup for systems',
  `icon` varchar(20) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

--
-- Table structure for table `systems`
--

DROP TABLE IF EXISTS `systems`;
CREATE TABLE `systems` (
  `id` int(11) NOT NULL auto_increment,
  `mac` varchar(30) NOT NULL,
  `name` varchar(30) NOT NULL default 'NOBODY',
  `description` varchar(100) NOT NULL,
  `uid` int(11) NOT NULL,
  `vlan` int(11) NOT NULL default '1',
  `comment` varchar(100) default NULL,
  `ChangeDate` varchar(100) default NULL,
  `ChangeUser` int(11) NOT NULL,
  `status` int(4) unsigned NOT NULL default '1',
  `LastSeen` datetime default NULL,
  `office` int(11) NOT NULL default '1',
  `LastPort` int(11) NOT NULL,
  `history` text,
  `LastVlan` int(11) NOT NULL,
  `os` int(11) unsigned NOT NULL,
  `os1` int(10) unsigned NOT NULL,
  `os2` int(10) unsigned NOT NULL,
  `os3` int(10) unsigned NOT NULL,
  `os4` varchar(64) default NULL,
  `class` int(11) unsigned NOT NULL,
  `class2` int(11) unsigned NOT NULL,
  `r_ip` varchar(20) default NULL,
  `r_timestamp` datetime default NULL,
  `r_ping_timestamp` datetime default NULL,
  `inventory` varchar(20) default NULL,
  `scannow` tinyint(4) default '0',
  `expiry` datetime default NULL,
  `dhcp_fix` tinyint(4) default NULL,
  `dhcp_ip` varchar(20) default NULL,
  `dns_alias` varchar(200) default NULL COMMENT 'CSV: for static DNS IP mgt',
  `health` int(11) default NULL COMMENT 'lookup into health table',
  `last_hostname` varchar(100) default NULL COMMENT 'dns or dhcp name + domain',
  `last_nbtname` varchar(100) default NULL COMMENT 'Netbios name',
  `last_uid` int(11) default NULL COMMENT 'last user logged on to PC',
  `email_on_connect` varchar(100) default NULL COMMENT 'email address to alert',
  `group_id` int(11) default NULL,
  `clear_mac` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `mac` (`mac`),
  KEY `office` (`office`),
  KEY `LastPort` (`LastPort`),
  KEY `class` (`class`),
  KEY `class2` (`class2`),
  KEY `os` (`os`),
  KEY `uid` (`uid`),
  KEY `ChangeUser` (`ChangeUser`),
  KEY `vlan` (`vlan`),
  KEY `LastVlan` (`LastVlan`),
  KEY `status` (`status`),
  KEY `os2` (`os2`),
  KEY `os1` (`os1`),
  KEY `os3` (`os3`),
  KEY `clear_mac` (`clear_mac`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='List of VMPS controlled computers';

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL auto_increment,
  `LastSeenDirectory` date NOT NULL default '0000-00-00',
  `username` varchar(100) NOT NULL,
  `Surname` varchar(100) NOT NULL,
  `GivenName` varchar(100) NOT NULL,
  `Department` varchar(100) default NULL,
  `rfc822mailbox` varchar(100) default NULL,
  `HouseIdentifier` varchar(100) default NULL,
  `PhysicalDeliveryOfficeName` varchar(100) default NULL,
  `TelephoneNumber` varchar(100) default NULL,
  `Mobile` varchar(100) default NULL,
  `nac_rights` int(11) default NULL,
  `manual_direx_sync` int(11) default NULL,
  `comment` varchar(200) default NULL,
  `GuiVlanRights` varchar(255) default NULL,
  `location` int(11) NOT NULL default '1',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `location` (`location`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Users details';

--
-- Table structure for table `vlan`
--

DROP TABLE IF EXISTS `vlan`;
CREATE TABLE `vlan` (
  `id` int(11) NOT NULL auto_increment,
  `default_name` varchar(30) NOT NULL,
  `default_id` int(11) default NULL,
  `vlan_description` varchar(100) default NULL,
  `vlan_group` int(11) default NULL,
  `color` varchar(6) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `default_name` (`default_name`),
  UNIQUE KEY `default_id` (`default_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

--
-- Table structure for table `vlanswitch`
--

DROP TABLE IF EXISTS `vlanswitch`;
CREATE TABLE `vlanswitch` (
  `vid` int(11) NOT NULL,
  `swid` int(11) NOT NULL,
  `vlan_id` int(11) NOT NULL,
  `vlan_name` varchar(100) NOT NULL,
  KEY `swid` (`swid`),
  KEY `vid` (`vid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

--
-- Table structure for table `vmpsauth`
--

DROP TABLE IF EXISTS `vmpsauth`;
CREATE TABLE `vmpsauth` (
  `sid` int(11) NOT NULL,
  `AuthLast` datetime default NULL,
  `AuthPort` int(11) NOT NULL,
  `AuthVlan` int(11) NOT NULL,
  UNIQUE KEY `Alter_Key3` (`sid`,`AuthPort`,`AuthVlan`),
  KEY `AuthPort` (`AuthPort`),
  KEY `AuthVlan` (`AuthVlan`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='List of VMPS authenticated Computers\nLocal on each server - ';

--
-- Table structure for table `vstatus`
--

DROP TABLE IF EXISTS `vstatus`;
CREATE TABLE `vstatus` (
  `id` int(10) unsigned NOT NULL,
  `value` varchar(30) NOT NULL,
  `color` varchar(6) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

--
-- Table structure for table `wsus_neededUpdates`
--

DROP TABLE IF EXISTS `wsus_neededUpdates`;
CREATE TABLE `wsus_neededUpdates` (
  `localupdateid` int(11) NOT NULL,
  `title` varchar(200) default NULL,
  `description` varchar(1500) default NULL,
  `msrcseverity` varchar(20) default NULL,
  `creationdate` datetime default NULL,
  `receiveddate` datetime default NULL,
  `lastsync` datetime NOT NULL,
  PRIMARY KEY  (`localupdateid`),
  UNIQUE KEY `localupdateid` (`localupdateid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='global list of needed updates, synced from wsus database';

--
-- Table structure for table `wsus_systemToUpdates`
--

DROP TABLE IF EXISTS `wsus_systemToUpdates`;
CREATE TABLE `wsus_systemToUpdates` (
  `id` int(11) NOT NULL auto_increment,
  `sid` int(11) NOT NULL,
  `localupdateid` int(11) NOT NULL,
  `lastsync` datetime NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='mapping of systems to updates';

--
-- Table structure for table `wsus_systems`
--

DROP TABLE IF EXISTS `wsus_systems`;
CREATE TABLE `wsus_systems` (
  `sid` int(11) NOT NULL,
  `hostname` varchar(255) NOT NULL,
  `ip` varchar(20) default NULL,
  `lastwsuscontact` datetime default NULL,
  `os` varchar(256) default NULL,
  `computermake` varchar(64) default NULL,
  `computermodel` varchar(64) default NULL,
  `notinstalled` int(11) default NULL,
  `downloaded` int(11) default NULL,
  `installedpendingreboot` int(11) default NULL,
  `failed` int(11) default NULL,
  `lastsync` datetime NOT NULL,
  PRIMARY KEY  (`sid`),
  UNIQUE KEY `sid` (`sid`),
  UNIQUE KEY `hostname` (`hostname`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='list of systems with the wsus client, synced from wsus datab';
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

