/*
Created		18.01.2007
Modified		19.03.2007
Project		
Model		
Company		
Author		
Version		
Database		mySQL 5 
*/


drop table IF EXISTS config;
drop table IF EXISTS cabletype;
drop table IF EXISTS sys_os3;
drop table IF EXISTS sys_os1;
drop table IF EXISTS sys_os2;
drop table IF EXISTS nac_wsuspatches;
drop table IF EXISTS vstatus;
drop table IF EXISTS naclog;
drop table IF EXISTS vmpsauth;
drop table IF EXISTS vlanswitch;
drop table IF EXISTS vlan;
drop table IF EXISTS users;
drop table IF EXISTS systems;
drop table IF EXISTS sys_os;
drop table IF EXISTS sys_class2;
drop table IF EXISTS sys_class;
drop table IF EXISTS switch;
drop table IF EXISTS subnets;
drop table IF EXISTS stat_systems;
drop table IF EXISTS stat_ports;
drop table IF EXISTS services;
drop table IF EXISTS protocols;
drop table IF EXISTS port;
drop table IF EXISTS patchcable;
drop table IF EXISTS oper;
drop table IF EXISTS nac_openports;
drop table IF EXISTS nac_hostscanned;
drop table IF EXISTS location;
drop table IF EXISTS guilog;
drop table IF EXISTS guirights;
drop table IF EXISTS ethernet;
drop table IF EXISTS dhcp_subnets;
drop table IF EXISTS dhcp_options;
drop table IF EXISTS building;
drop table IF EXISTS auth_profile;
drop table IF EXISTS health;
drop table IF EXISTS stats;
drop table IF EXISTS epo_systems;
drop table IF EXISTS wsus_systems;
drop table IF EXISTS wsus_neededUpdates;
drop table IF EXISTS wsus_systemToUpdates; 


Create table auth_profile (
	id Int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
	method Varchar(16) NOT NULL COMMENT 'access config : static, vmps, 8021x',
	config Text COMMENT 'optionnal : configuration instructions ',
 Primary Key (id)) ENGINE = MyISAM
ROW_FORMAT = Dynamic;

Create table building (
	id Int(11) NOT NULL AUTO_INCREMENT,
	name Varchar(64) NOT NULL,
 Primary Key (id)) ENGINE = MyISAM
ROW_FORMAT = Dynamic;

Create table dhcp_options (
	id Int(11) NOT NULL AUTO_INCREMENT,
	scope Int(11) NOT NULL,
	name Varchar(128) NOT NULL,
	value Varchar(256) NOT NULL,
 Primary Key (id)) ENGINE = MyISAM
ROW_FORMAT = Dynamic;

Create table dhcp_subnets (
	id Int(11) NOT NULL AUTO_INCREMENT,
	subnet_id Int(11) NOT NULL,
	dhcp_from Varchar(15) NOT NULL,
	dhcp_to Varchar(15) NOT NULL,
	dhcp_defaultrouter Varchar(128) NOT NULL,
 Primary Key (id)) ENGINE = MyISAM
ROW_FORMAT = Dynamic;

Create table ethernet (
	vendor Varchar(16) NOT NULL,
	mac Varchar(6) NOT NULL,
	UNIQUE (mac),
 Primary Key (mac)) ENGINE = MyISAM
ROW_FORMAT = Dynamic;

Create table guirights (
	code Int(11) NOT NULL DEFAULT "0",
	value Varchar(30) NOT NULL,
	ad_group Varchar(255) DEFAULT NULL,
 Primary Key (code)) ENGINE = MyISAM
ROW_FORMAT = Dynamic;

Create table guilog (
	id Serial NOT NULL AUTO_INCREMENT,
	who Int NOT NULL,
	host Varchar(30) NOT NULL,
	datetime Timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
	priority Enum('info','err','crit') DEFAULT "info",
	what Varchar(200) NOT NULL,
	UNIQUE (id)) ENGINE = MyISAM
ROW_FORMAT = Dynamic;

Create table location (
	id Int(15) NOT NULL AUTO_INCREMENT,
	building_id Int(11) NOT NULL DEFAULT 1,
	name Varchar(64) NOT NULL,
 Primary Key (id)) ENGINE = MyISAM
ROW_FORMAT = Dynamic;

Create table nac_hostscanned (
	sid Int(11) NOT NULL,
	id Int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
	ip Varchar(15) NOT NULL,
	hostname Varchar(80),
	os Varchar(80),
	timestamp Datetime,
	UNIQUE (sid),
	UNIQUE (id),
 Primary Key (id)) ENGINE = MyISAM
ROW_FORMAT = Dynamic;

Create table nac_openports (
	id Int(11) NOT NULL AUTO_INCREMENT,
	sid Int(10) NOT NULL,
	service Int NOT NULL,
	banner Varchar(128),
	timestamp Datetime,
 Primary Key (id)) ENGINE = MyISAM
ROW_FORMAT = Dynamic;

Create table oper (
	value Enum('guiupdate','vmpsupdate','vmpscheck','server1','server2','lastseen1','lastseen2') NOT NULL DEFAULT "guiupdate",
	datetime Timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
	comment Varchar(66) NOT NULL) ENGINE = MyISAM
ROW_FORMAT = Dynamic
COMMENT = 'Status of GUI and daemons';

Create table patchcable (
	id Int NOT NULL AUTO_INCREMENT,
	rack Varchar(30) DEFAULT NULL,
	rack_location Varchar(30) DEFAULT NULL,
	outlet Varchar(30) DEFAULT NULL,
	other Varchar(30) DEFAULT NULL,
	office Int NOT NULL DEFAULT 1,
	type Int NOT NULL DEFAULT "0",
	port Int NOT NULL,
	comment Varchar(255) DEFAULT NULL,
	lastchange Timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
	modifiedby Int NOT NULL,
	expiry Date,
 Primary Key (id)) ENGINE = MyISAM
ROW_FORMAT = Dynamic
COMMENT = 'Patch cables from Office Sockets to Port Switches';

Create table port (
	id Int(11) NOT NULL AUTO_INCREMENT,
	switch Int NOT NULL,
	name Varchar(20) NOT NULL,
	comment Varchar(255),
	restart_now Int(11),
	default_vlan Int(11) DEFAULT NULL,
	snmp_idx Int(11),
	last_vlan Int(11) DEFAULT NULL,
	last_activity Datetime,
	auth_profile Int(11) UNSIGNED DEFAULT NULL,
	last_monitored Datetime Comment "Last time the port was monitored",
	up int comment "Monitor: port is up(1) or down?",
	last_auth_profile int comment "Is port static/dynamic? (lookup table auth_profile)",
	staticvlan int comment "If static, program this vlan",
	shutdown int comment "Shutdown the port(1)?",
 Primary Key (id)) ENGINE = MyISAM
ROW_FORMAT = Dynamic;

Create table protocols (
	protocol Int(11) NOT NULL DEFAULT "0",
	name Varchar(50),
	description Varchar(50),
 Primary Key (protocol)) ENGINE = MyISAM
ROW_FORMAT = Dynamic;

Create table services (
	id Int(11) NOT NULL AUTO_INCREMENT,
	port Int(11) NOT NULL,
	protocol Int(11) NOT NULL DEFAULT "6",
	name Varchar(50) NOT NULL,
	description Varchar(255) DEFAULT NULL,
 Primary Key (id)) ENGINE = MyISAM
ROW_FORMAT = Dynamic;

Create table stat_ports (
	date Date NOT NULL DEFAULT "0000-00-00",
	auth_profile Int(11) UNSIGNED NOT NULL DEFAULT "0",
	count Int(11)) ENGINE = MyISAM
ROW_FORMAT = Fixed;

Create table stat_systems (
	date Date NOT NULL DEFAULT "0000-00-00",
	vstatus Int(10) UNSIGNED NOT NULL,
	count Int(11)) ENGINE = MyISAM
ROW_FORMAT = Fixed;

Create table subnets (
	id Int(11) NOT NULL AUTO_INCREMENT,
	ip_address Varchar(20) NOT NULL,
	ip_netmask Int(4) NOT NULL,
	scan Tinyint(4) DEFAULT '0',
	dontscan Varchar(128),
 Primary Key (id)) ENGINE = MyISAM
ROW_FORMAT = Dynamic;

Create table switch (
	id Int(11) NOT NULL AUTO_INCREMENT,
	ip Varchar(20) DEFAULT NULL,
	name Varchar(20) DEFAULT NULL,
	location Int DEFAULT NULL,
	comment Varchar(50) DEFAULT NULL,
	swgroup Varchar(20) DEFAULT NULL,
	notify Varchar(200) DEFAULT NULL,
	ap Tinyint(4) NOT NULL DEFAULT "0",
	scan Tinyint(1),
	hw Char(64),
	sw Char(64),
	last_monitored datetime comment "Last time the switch was polled",
	up int comment "Monitor: switch is reachable(1) or down?",
	vlan_id int(11) DEFAULT NULL,
 Primary Key (id)) ENGINE = MyISAM
ROW_FORMAT = Dynamic;

Create table sys_class (
	id Int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Unique Number',
	value Varchar(30) NOT NULL COMMENT 'Class lookup for systems',
	UNIQUE (id),
 Primary Key (id)) ENGINE = MyISAM
ROW_FORMAT = Dynamic
COMMENT = 'Device Types';

Create table sys_class2 (
	id Int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Unique Number',
	value Varchar(30) NOT NULL,
	UNIQUE (id),
 Primary Key (id)) ENGINE = MyISAM
ROW_FORMAT = Dynamic;

Create table sys_os (
	id Int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
	value Varchar(30) NOT NULL COMMENT 'Operating System lookup for systems',
	icon Varchar(20),
	UNIQUE (id),
 Primary Key (id)) ENGINE = MyISAM
ROW_FORMAT = Dynamic;

Create table systems (
	id Int(11) NOT NULL AUTO_INCREMENT,
	mac Varchar(30) NOT NULL,
	name Varchar(30) NOT NULL DEFAULT "NOBODY",
	description Varchar(100) DEFAULT NULL COMMENT "v3: not used",
	uid Int(11) DEFAULT NULL,
	vlan Int(11) NOT NULL DEFAULT "13",
	comment Varchar(100),
	ChangeDate Varchar(100) DEFAULT NULL,
	ChangeUser Int DEFAULT NULL,
	status Int(4) UNSIGNED NOT NULL DEFAULT "1",
	LastSeen Datetime,
	office Int NOT NULL DEFAULT 1,
	LastPort Int DEFAULT NULL,
	history Text,
	LastVlan Int DEFAULT NULL,
	os Int(11) UNSIGNED DEFAULT NULL,
	os1 Int UNSIGNED DEFAULT NULL,
	os2 Int UNSIGNED DEFAULT NULL,
	os3 Int UNSIGNED DEFAULT NULL,
	os4 Varchar(64) DEFAULT NULL,
	class Int(11) UNSIGNED DEFAULT NULL,
	class2 Int(11) UNSIGNED DEFAULT NULL,
	r_ip Varchar(20),
	r_timestamp Datetime,
	r_ping_timestamp Datetime,
	inventory Varchar(20),
	scannow Tinyint(4) DEFAULT "0",
	expiry Datetime,
	dhcp_fix Tinyint(4),
	dhcp_ip Varchar(20),
	dns_alias varchar(200) comment "CSV: for static DNS IP mgt",
	health int comment "Lookup into health table",
	last_hostname varchar(100) comment "DNS or DHCP name + domain",
	last_nbtname varchar(100) comment "Netbios name",
	last_uid int comment "Last user logged on to PC",
	email_on_connect varchar(100) comment "Email address to alert",
	group_id int(11) default NULL,
	UNIQUE (id),
 Primary Key (id)) ENGINE = MyISAM
ROW_FORMAT = Dynamic
COMMENT = 'List of VMPS controlled computers';

Create table health (
	id int(10) unsigned NOT NULL,
	value varchar(30) NOT NULL,
	color varchar(6) DEFAULT NULL,
	`comment` varchar(100) NOT NULL,
	Primary Key (id)) ENGINE = MyISAM 
ROW_FORMAT = Dynamic
COMMENT = 'List of health status';

Create table users (
	id Int(11) NOT NULL AUTO_INCREMENT,
	LastSeenDirectory Date NOT NULL DEFAULT "0000-00-00",
	username Varchar(100) NOT NULL,
	Surname Varchar(100) NOT NULL,
	GivenName Varchar(100) NOT NULL,
	Department Varchar(100),
	rfc822mailbox Varchar(100),
	HouseIdentifier Varchar(100),
	PhysicalDeliveryOfficeName Varchar(100),
	TelephoneNumber Varchar(100),
	Mobile Varchar(100),
	nac_rights Int(11),
	manual_direx_sync Int(11),
	comment Varchar(200),
	GuiVlanRights Varchar(255),
	location Int NOT NULL DEFAULT 1,
	UNIQUE (username),
 Primary Key (id)) ENGINE = MyISAM
ROW_FORMAT = Dynamic
COMMENT = 'Users details';

Create table vlan (
	id Int(11) NOT NULL AUTO_INCREMENT,
	default_name Varchar(30) NOT NULL,
	default_id Int,
	vlan_description Varchar(100),
	vlan_group Int(11),
	color Varchar(6),
	UNIQUE (id),
	UNIQUE (default_name),
	UNIQUE (default_id),
 Primary Key (id)) ENGINE = MyISAM
ROW_FORMAT = Dynamic;

Create table vlanswitch (
	vid Int(11) NOT NULL,
	swid Int(11) NOT NULL,
	vlan_id Int(11) DEFAULT NULL,
	vlan_name Varchar(100) NOT NULL) ENGINE = MyISAM
ROW_FORMAT = Dynamic;

Create table vmpsauth (
	sid Int NOT NULL,
	AuthLast Datetime,
	AuthPort Int NOT NULL,
	AuthVlan Int(11) NOT NULL) ENGINE = MyISAM
ROW_FORMAT = Dynamic
COMMENT = 'List of VMPS authenticated Computers
Local on each server - not replicated
Used only by vmps_external';

Create table naclog (
	id Serial NOT NULL AUTO_INCREMENT,
	who Int NOT NULL,
	host Varchar(30) NOT NULL,
	datetime Timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
	priority Enum('info','err','crit') DEFAULT "info",
	what Varchar(200) NOT NULL,
	UNIQUE (id)) ENGINE = MyISAM
ROW_FORMAT = Dynamic
COMMENT = 'Log of server activities';

Create table vstatus (
	id Int(10) UNSIGNED NOT NULL,
	value Varchar(30) NOT NULL,
	color Varchar(6),
 Primary Key (id)) ENGINE = MyISAM
ROW_FORMAT = Dynamic;

Create table nac_wsuspatches (
	LocalUpdateID Int NOT NULL,
	UpdateID Varchar(38) NOT NULL COMMENT 'Microsoft KB number',
	Title Varchar(200),
	KBArticleID Varchar(15) NOT NULL,
	UNIQUE (LocalUpdateID),
 Primary Key (UpdateID)) ENGINE = MyISAM;

Create table sys_os2 (
	id Int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
	value Varchar(30) NOT NULL COMMENT 'Operating System lookup for systems',
	icon Varchar(20),
	UNIQUE (id),
 Primary Key (id)) ENGINE = MyISAM
ROW_FORMAT = Dynamic;

Create table sys_os1 (
	id Int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
	value Varchar(30) NOT NULL COMMENT 'Operating System lookup for systems',
	icon Varchar(20),
	UNIQUE (id),
 Primary Key (id)) ENGINE = MyISAM
ROW_FORMAT = Dynamic;

Create table sys_os3 (
	id Int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
	value Varchar(30) NOT NULL COMMENT 'Operating System lookup for systems',
	icon Varchar(20),
	UNIQUE (id),
 Primary Key (id)) ENGINE = MyISAM
ROW_FORMAT = Dynamic;

Create table cabletype (
	id Int NOT NULL AUTO_INCREMENT,
	name Varchar(64),
	UNIQUE (id),
 Primary Key (id)) ENGINE = MyISAM;

Create table config (
	id Int NOT NULL AUTO_INCREMENT,
	type Varchar(16),
	name Varchar(64),
	value Varchar(255),
	comment Varchar(255),
	LastChange Timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
	who Int,
	UNIQUE (id),
 Primary Key (id)) ENGINE = MyISAM;

CREATE TABLE `stats` (
  `id` int(11) NOT NULL auto_increment,
  `code` varchar(100) default NULL,
  `value` int(11) NOT NULL,
  `datetime` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

CREATE TABLE epo_systems (
  sid int not null,
  nodename varchar(30),
  domainname varchar(100),
  ip varchar(20),
  mac varchar(30) not null,
  agentversion varchar(50),
  lastepocontact datetime,
  virusver varchar(50),
  virusenginever varchar(100),
  virusdatver varchar(50),
  virushotfix varchar(100),
  ostype varchar(100),
  osversion varchar(100),
  osservicepackver varchar(100),
  osbuildnum int,
  freediskspace int,
  username varchar(128),
  lastsync datetime not null,
  PRIMARY KEY (sid),
  unique key (sid),
  UNIQUE KEY (mac)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='list of systems with the epo client installed, synced from epo database';

CREATE TABLE epo_versions (
  id int not null auto_increment,
  product varchar(255) not null,
  version varchar(255) not null,
  hotfix varchar(32),
  lastsync datetime not null,
  primary key (id),
  unique key (id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='current version of epo products, synced from epo database';

create table if not exists wsus_systems (
	sid int not null,
	hostname varchar(255) not null,
	ip varchar(20),
	lastwsuscontact datetime,
	os varchar(256), 
	computermake varchar(64), 
	computermodel varchar(64),
	notinstalled int,
	downloaded int,
	installedpendingreboot int,
	failed int,
	lastsync datetime not null,
	primary key (sid),
	unique (sid),
	unique (hostname)		
) engine=myisam default charset=utf8 row_format=dynamic comment='list of systems with the wsus client, synced from wsus database';

create table if not exists wsus_neededUpdates (
	localupdateid int not null,
	title varchar(200),
	description varchar(1500),
	msrcseverity varchar(20),
	creationdate datetime,
	receiveddate datetime,
	lastsync datetime not null,
	primary key (localupdateid),
	unique (localupdateid)
) engine=myisam default charset=utf8 row_format=dynamic comment='global list of needed updates, synced from wsus database';

create table if not exists wsus_systemToUpdates (
	id int not null auto_increment,
	sid int not null,
	localupdateid int not null,
	lastsync datetime not null,
	primary key (id),
	unique (id)
) engine=myisam default charset=utf8 row_format=dynamic comment='mapping of systems to updates';
