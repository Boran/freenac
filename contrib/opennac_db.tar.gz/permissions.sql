grant SELECT,INSERT,UPDATE ON opennac.* to inventwrite@localhost IDENTIFIED by 'PASSWORD2';
SET PASSWORD FOR inventwrite@localhost = OLD_PASSWORD('PASSWORD2');

grant SELECT,INSERT,UPDATE,DELETE ON opennac.systems to inventwrite@localhost;
grant CREATE TEMPORARY TABLES ON opennac.* to inventwrite@localhost;
grant ALL ON opennac.vmpsauth to inventwrite@localhost;

grant SELECT,INSERT ON opennac.* to inventwrite@'%' IDENTIFIED by 'PASSWORD1';
SET PASSWORD FOR inventwrite@'%' = OLD_PASSWORD('PASSWORD1');

grant SELECT,UPDATE ON opennac.oper to inventwrite@'%' ;
grant SELECT,UPDATE ON opennac.config to inventwrite@'%' ;
grant SELECT,INSERT,UPDATE,DELETE ON opennac.building to inventwrite@'%' ;
grant SELECT,INSERT,UPDATE,DELETE ON opennac.location to inventwrite@'%' ;
grant SELECT,INSERT,UPDATE,DELETE ON opennac.port to inventwrite@'%' ;
grant SELECT,INSERT,UPDATE,DELETE ON opennac.switch to inventwrite@'%' ;
grant SELECT,INSERT,UPDATE,DELETE ON opennac.vlan to inventwrite@'%' ;
grant SELECT,INSERT,UPDATE,DELETE ON opennac.systems to inventwrite@'%';
grant SELECT,INSERT,UPDATE,DELETE ON opennac.users to inventwrite@'%' ;
grant SELECT,INSERT,UPDATE,DELETE ON opennac.patchcable to inventwrite@'%';
grant SELECT,INSERT,UPDATE,DELETE ON opennac.vlanswitch to inventwrite@'%' ;
grant SELECT,INSERT,UPDATE,DELETE ON opennac.cabletype to inventwrite@'%' ;
grant SELECT,INSERT,UPDATE,DELETE ON opennac.sys_class to inventwrite@'%' ;
grant SELECT,INSERT,UPDATE,DELETE ON opennac.sys_class2 to inventwrite@'%' ;
grant SELECT,INSERT,UPDATE,DELETE ON opennac.sys_os to inventwrite@'%';
grant SELECT,INSERT,UPDATE,DELETE ON opennac.sys_os1 to inventwrite@'%';
grant SELECT,INSERT,UPDATE,DELETE ON opennac.sys_os2 to inventwrite@'%';
grant SELECT,INSERT,UPDATE,DELETE ON opennac.sys_os3 to inventwrite@'%';

grant SELECT, INSERT,UPDATE,DELETE ON opennac.nac_hostscanned to inventwrite@'localhost';
grant SELECT, INSERT,UPDATE,DELETE ON opennac.nac_openports to inventwrite@'localhost';
grant SELECT ON opennac.nac_hostscanned to inventwrite@'%';
grant SELECT ON opennac.nac_openports to inventwrite@'%';
grant SELECT on opennac.protocols to inventwrite@'%';
grant SELECT on opennac.services to inventwrite@'%';
grant SELECT, INSERT,UPDATE,DELETE on opennac.subnets to inventwrite@'%';

grant select, update, insert, delete on opennac.epo_versions to inventwrite@'localhost';
grant select, update, insert, delete on opennac.epo_systems to inventwrite@'localhost';
grant select, update, insert, delete on opennac.wsus_systems to inventwrite@'localhost';
grant select, update, insert, delete on opennac.wsus_systemToUpdates to inventwrite@'localhost';
grant select, update, insert, delete on opennac.wsus_neededUpdates to inventwrite@'localhost';
grant select on opennac.epo_versions to inventwrite@'%';
grant select on opennac.epo_systems to inventwrite@'%';
grant select on opennac.wsus_systems to inventwrite@'%';
grant select on opennac.wsus_systemToUpdates to inventwrite@'%';
grant select on opennac.wsus_neededUpdates to inventwrite@'%';

grant select on opennac.health to inventwrite@'localhost';
grant select on opennac.health to inventwrite@'%';
