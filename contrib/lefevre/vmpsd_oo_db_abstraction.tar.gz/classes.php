<?

require_once "OOdb-0.6.1.php";
require_once "Fork.php";
require_once "funcs.inc";
//require_once "functions.php";

class System extends dbObject {
	public static function _dbInfo() { return array("table"=>'systems',"key"=>'id'); }
    
	public function configure() {
		$this->_types = array(
		        "id" => "int",
		        "mac" => "text",
		        "name" => "text",
		        "description" => "text",
		        "uid" => "int",
		        "vlan" => "int",
		        "comment" => "text",
		        "ChangeDate" => "text",
		        "ChangeUser" => "int",
		        "status" => "int",
		        "LastSeen" => "datetime",
		        "office" => "int",
		        "LastPort" => "int",
		        "history" => "text",
		        "LastVlan" => "int",
		        "os" => "int",
		        "os1" => "int",
		        "os2" => "int",
		        "os3" => "int",
		        "os4" => "text",
		        "class" => "int",
		        "class2" => "int",
		        "r_ip" => "text",
		        "r_timestamp" => "datetime",
		        "r_ping_timestamp" => "datetime",
		        "inventory" => "text",
		        "scannow" => "int",
		        "expiry" => "datetime",
		        "dhcp_fix" => "int",
		        "dhcp_ip" => "text" 
		        );
        
		$this->_singles[] = array('VLAN', 'vlan', 'VLAN', 'id', true);
		$this->_singles[] = array('LastVLAN', 'LastVlan', 'VLAN', 'id', true);
		$this->_singles[] = array('Port', 'LastPort', 'Port', 'id', true);
		$this->_singles[] = array('VMPSAuth', 'id', 'VMPSAuth', 'sid', true);
		$this->_singles[] = array('Location', 'office', 'Location', 'id', true);
		$this->_singles[] = array('SystemClass', 'sys_class', 'SystemClass', 'id', true);
		$this->_singles[] = array('SystemOS', 'sys_os', 'SystemOS', 'id', true);
		$this->_singles[] = array('SystemOSVersion', 'sys_os1', 'SystemOSVersion', 'id', true);
		$this->_singles[] = array('SystemOSServicePack', 'sys_os2', 'SystemOSServicePack', 'id', true);
		$this->_singles[] = array('SystemPlatfrom', 'sys_os3', 'SystemPlatform', 'id', true);
		$this->_singles[] = array('User', 'uid', 'User', 'id', true);
		$this->_singles[] = array('ChangedBy', 'ChangeUser', 'User', 'id', true);
	}

	protected function _normalizeMac() {
		// Normalise mac address format,  Add . every 4 digit
		if ( $this->mac != '') {
			$mac = $this->mac;
			$mac = preg_replace('/-|\.|\s/', '', $mac);  #remove space, dash, dots
			$this->mac = "$mac[0]$mac[1]$mac[2]$mac[3].$mac[4]$mac[5]$mac[6]$mac[7].$mac[8]$mac[9]$mac[10]$mac[11]";
		}
	}

	public function __construct($db, $values) {
		parent::__construct($db, $values);
		$this->_normalizeMac();
	}

	public function __destruct() {
		parent::__destruct();
	}

	/** 
	 * Tests to see if System is past expiration date (ie. expired)
	 * @return true|false
	 */
	public function expired() {
	        if ($this->expiry == "") {
	        	# No.
	        	return false;
	        }
	        if ($this->expiry && (strcmp(trim($this->expiry),"0000-00-00 00:00:00") == 0)) {
	        	# No.  Don't bother checking further
	        	return false;
	        }
	        else
	        { # check for expiration
	        	$timestamp = date('Y-m-d H:i:s');
	        	$time = time_diff($timestamp,$expiry);
	        	if ($time<0)
	        	{
	        		return true;
			}
		}
		return false;
	}

	public function active() {
		if ($this->status == 1 ) { return true; }
		if ($this->status == 7 ) { return false; }
		return true;
	}

	/**
	 * Returns MACVendor object
	 * @return bdObject MACVendor
	 */
	public function getMACVendor() {
		$parts = explode('.', $this->mac);
		$vendors6 = substr($parts[0].$parts[1], 0, 6);
		$obj = $this->_db->getObject('MACVendor', $vendors6);
		return $obj;
	}

	/**
	 * Determines if mac address is registered to VMWare
	 * @return bool true/false
	 */
	public function isVM() {
		$v = $this->getMACVendor();
		if (strcasecmp( substr($v->vendor,0,6), "vmware") == 0) {
			return true;
		}
		return false;
	}

}


class VLAN extends dbObject {
	public static function _dbInfo() { return array("table"=>'vlan',"key"=>'id'); }

	public function configure() {
		$this->_types = array(
			"id" => "int",
			"default_name" => "text",
			"default_id" => "int",
			"vlan_description" => "text",
			"vlan_group" => "int",
			"color" => "text"
			);

		$this->_multis[] = array('SwitchesDefaults', 'id', 'SwitchVLAN', 'vid');
	}

	public function __destruct() {
		parent::__destruct();
	}

}


class SwitchVLAN extends dbObject {
      public static function _dbInfo() {return array("table"=>'vlanswitch',"key"=>'swid'); }
      
      public function configure() {
        $this->_types = array(
	  "vid" => "Int",
	  "swid" => "Int",
	  "vlan_id" => "Int",
	  "vlan_name" => "Varchar(100)"
	  );
      $this->_singles[] = array('Switch', 'swid', 'NetworkSwitch', 'id', true);
      $this->_singles[] = array('VLAN', 'vid', 'VLAN', 'id', true);
      }

	public function __destruct() {
		parent::__destruct();
	}

}

class NetworkSwitch extends dbObject {
	public static function _dbInfo() { return array("table"=>'switch',"key"=>'id'); }

	public function configure() {
		$this->_types = array(
			"id" => "int",
			"ip" => "text",
			"name" => "text",
			"location" => "int",
			"comment" => "text",
			"swgroup" => "text",
			"notify" => "text",
			"ap" => "int",
			"scan" => "int",
			"hw" => "text",
			"sw" => "text"
			);

		$this->_multis[] = array('Ports', 'id', 'Port', 'switch');
		$this->_singles[] = array('DefaultVLAN', 'id', 'SwitchVLAN', 'swid', true);
		$this->_singles[] = array('Location', 'location', 'Location', 'id', true);
	}

	public function __destruct() {
		parent::__destruct();
	}

	/**
	 * Retrieves an associated port by key(s) and value(s)
	 * @param arrary $values Associative array of keys and values for search
	 * @return array Array of Port objects
	 */
	public function getPorts($values) {
		$sw_id = array("switch" => $this->getKeyValue() );
		$criteria = array_merge($sw_id, $values);
		return $this->_db->getObjects('Port', $criteria);
	}

	/**
	 * Retrieves an associated Port by Name
	 * @param string $name Name of Port to return
	 * @return Port
	 */
	public function PortByName($name) {
		$objects = array();
		$objects = $this->getPorts( array("name" => $name) );
		return $objects[0];
	}
}


class Port extends dbObject {
	public static function _dbInfo() { return array("table"=>'port',"key"=>'id'); }

	public function configure() {
		$this->_types = array(
			"id" => "int",
			"switch" => "int",
			"name" => "text",
			"comment" => "text",
			"restart_now" => "int",
			"default_vlan" => "int",
			"snmp_idx" => "int",
			"last_vlan" => "int",
			"last_activity" => "Datetime",
			"auth_profile" => "int"
			);

		$this->_singles[] = array('Switch', 'switch', 'NetworkSwitch', 'id', true);
		$this->_singles[] = array('LastVLAN', 'last_vlan', 'VLAN', 'id', true);
		$this->_singles[] = array('DefaultVLAN', 'default_vlan', 'VLAN', 'id', true);
		$this->_multis[] = array('VMPSAuths', 'id', 'VMPSAuth', 'AuthPort');
	}

	public function __destruct() {
		parent::__destruct();
	}

}
              
class VMPSAuth extends dbObject {
	public static function _dbInfo() {return array("table"=>'vmpsauth',"key"=>'sid'); }

	public function configure() {
		$this->_types = array(
			"sid" => "int",
			"AuthLast" => "datetime",
			"AuthPort" => "int",
			"AuthVlan" => "int"
			);
		$this->_singles[] = array('System', 'sid', 'System', 'id', true);
		$this->_singles[] = array('Port', 'AuthPort', 'Port', 'id', true);
		$this->_singles[] = array('VLAN', 'AuthVlan', 'VLAN', 'id', true);
	}

	public function __destruct() {
		parent::__destruct();
	}

}

class Location extends dbObject {
	public static function _dbInfo() {return array("table"=>'location',"key"=>'id'); }

	public function configure() {
		$this->_types = array(
			"id" => "int",
			"building_id" => "int",
			"name" => "varchar(64)"
			);
		$this->_singles[] = array('Building', 'building_id', 'Building', 'id', true);
	}

	public function __destruct() {
		parent::__destruct();
	}

}

class Building extends dbObject {
	public static function _dbInfo() {return array("table"=>'building',"key"=>'id'); }

	public function configure() {
		$this->_types = array(
			"id" => "int",
			"name" => "varchar(64)"
			);
	}

	public function __destruct() {
		parent::__destruct();
	}

}

class SystemClass extends dbObject {
	public static function _dbInfo() {return array("table"=>'sys_class',"key"=>'id'); }

	public function configure() {
		$this->_types = array(
			"id" => "int",
			"value" => "varchar(30)"
			);
	}

	public function __destruct() {
		parent::__destruct();
	}

}
                    
class SystemOS extends dbObject {
	public static function _dbInfo() {return array("table"=>'sys_os',"key"=>'id'); }

	public function configure() {
		$this->_types = array(
			"id" => "int",
			"value" => "varchar(30)",
			"icon" => "varchar(20)"
			);
	}

	public function __destruct() {
		parent::__destruct();
	}

}

class SystemOSVersion extends dbObject {
	public static function _dbInfo() {return array("table"=>'sys_os1',"key"=>'id'); }

	public function configure() {
		$this->_types = array(
			"id" => "int",
			"value" => "varchar(30)",
			"icon" => "varchar(20)"
			);
	}

	public function __destruct() {
		parent::__destruct();
	}

}
                                                                            
class SystemOSServicePack extends dbObject {
	public static function _dbInfo() {return array("table"=>'sys_os2',"key"=>'id'); }

	public function configure() {
		$this->_types = array(
			"id" => "int",
			"value" => "varchar(30)",
			"icon" => "varchar(20)"
			);
	}

	public function __destruct() {
		parent::__destruct();
	}

}

class SystemPlatform extends dbObject {
	public static function _dbInfo() {return array("table"=>'sys_os3',"key"=>'id'); }

	public function configure() {
		$this->_types = array(
			"id" => "int",
			"value" => "varchar(30)",
			"icon" => "varchar(20)"
			);
	}

	public function __destruct() {
		parent::__destruct();
	}

}

class User extends dbObject {
	public static function _dbInfo() {return array("table"=>'users',"key"=>'id'); }

	public function configure() {
		$this->_types = array(
			"id" => "int",
			"LastSeenDirectory" => "Date",
			"username" => "Varchar(100)",
			"Surname" => "Varchar(100)",
			"GivenName" => "Varchar(100)",
			"Department" => "Varchar(100)",
			"rfc822mailbox" => "Varchar(100)",
			"HouseIdentifier" => "Varchar(100)",
			"PhysicalDeliveryOfficeName" => "Varchar(100)",
			"TelephoneNumber" => "Varchar(100)",
			"Mobile" => "Varchar(100)",
			"nac_rights" => "Int",
			"manual_direx_sync" => "Int",
			"comment" => "Varchar(200)",
			"GuiVlanRights" => "Varchar(255)",
			"location" => "Int"
			);
		$this->_singles[] = array('Location', 'location', 'Location', 'id', true);
	}

	public function __destruct() {
		parent::__destruct();
	}

}

class PatchCable extends dbObject {
	public static function _dbInfo() {return array("table"=>'patchcable',"key"=>'id'); }

	public function configure() {
		$this->_types = array(
			"id" => "Int",
			"rack" => "Varchar(30)",
			"rack_location" => "Varchar(30)",
			"outlet" => "Varchar(30)",
			"other" => "Varchar(30)",
			"office" => "Int",
			"type" => "Int",
			"port" => "Int",
			"comment" => "Varchar(255)",
			"lastchange" => "Timestamp",
			"modifiedby" => "Int",
			"expiry" => "Date"
			);
		$this->_singles[] = array('Location', 'office', 'Location', 'id', true);
		$this->_singles[] = array('Port', 'port', 'Port', 'id', true);
		$this->_singles[] = array('ChangedBy', 'modifiedby', 'User', 'id', true);
		$this->_singles[] = array('CableType', 'type', 'CableType', 'id', true);
	}

	public function __destruct() {
		parent::__destruct();
	}

}

class CableType extends dbObject {
	public static function _dbInfo() {return array("table"=>'cabletype',"key"=>'id'); }

	public function configure() {
		$this->_types = array(
			"id" => "int",
			"value" => "varchar(64)"
			);
	}

	public function __destruct() {
		parent::__destruct();
	}

}


class MACVendor extends dbObject {
	public static function _dbInfo() {return array("table"=>'ethernet',"key"=>'mac'); }

	public function configure() {
		$this->_types = array(
			"vendor" => "varchar(16)",
			"mac" => "varchar(6)"
			);
	}

	public function __destruct() {
		parent::__destruct();
	}

}

class NACRequest { 
	// request values 
	private $_mac; 
	private $_vtpdomain; 
	private $_switchip; 
	private $_portname; 
	private $_lastvlanname; 

	// objects 
	protected $_System; 
	protected $_Switch; 
	protected $_Port; 
	protected $_lastVLAN;
	protected $_VLAN;
	protected $_db; 
	         
	// response 
	private $_status;  // true = Allow / false = Deny 

           
	public function __construct($db, $domain, $switch, $port, $lastvlan, $mac) {
		$this->_db = $db;  
		$this->_vtpdomain = $domain; 
		$this->_switchip = $switch; 
		$this->_portname = $port; 
		$this->_lastvlanname = trim($lastvlan);
		$this->_mac = $mac;  
		$this->_normalizeMAC(); 

		$this->_status = false;
		$this->_VLAN = NULL;
	        
		// load objects from DB
		$this->_System = $this->_db->getObject("System", $this->_mac, "mac" );
		$this->_Switch = $this->_db->getObject("NetworkSwitch", $this->_switchip, "ip" );
		// if the switch exists then lookup the port
		if ($this->_Switch != NULL) {
			$this->_Port = $this->_Switch->PortByName($this->_portname);
		} else {
			// otherwise Switch will be NULL and Port should be NULL to indicate new switch & port
			$this->_Port = NULL;
		}
		if ($this->_lastvlanname != '') {
			$this->_lastVLAN = $this->_db->getObject("VLAN", $this->_lastvlanname, "default_name" );
		} else {
			$this->_lastVLAN = NULL;
		}
	} 
	                               
	protected function _normalizeMAC() { 
		if ( $this->_mac != '') {
			$mac = $this->_mac;
			$mac = preg_replace('/-|\.|\s/', '', $mac);  #remove space, dash, dots
			$this->_mac = "$mac[0]$mac[1]$mac[2]$mac[3].$mac[4]$mac[5]$mac[6]$mac[7].$mac[8]$mac[9]$mac[10]$mac[11]";
		}
	} 
	                                    
	public function vmpsdResponse() { 
		if ($this->_status == true) { 
			$rs = "ALLOW " . $this->_VLAN->default_name ."\n"; 
		} else { 
			$rs = "DENY\n"; 
		} 
		return $rs; 
	} 
	
	public function System() { return $this->_System; }
	public function NetworkSwitch() { return $this->_Switch; }
	public function Port()   { return $this->_Port;   }
	public function LastVLAN() { return $this->_lastVLAN; }
	public function Allowed( $state = -1 ) {
		if ( ($state == true) || ($state == false) ) {
			$this->_status = $state;
		}
		return $this->_status;
	}

	/**
	 * Assign VLAN for request
	 * @param VLAN $vlan  VLAN for assignment
	 */
	public function AssignVLAN($vlan) {
		$this->_VLAN = $vlan;
		/**
		if ($vlan != NULL) {
			if ($this->_VLAN->default_name != "--BLOCKED--") {
				$this->Allowed(true);
			}
		}
		**/
	}
	                                                            
}

/**
 * Resolves/Answers NAC/VMPS requests
 * This class is intended to receive the NAC request and respond to it.
 *
 */

abstract class NACResolver {
	protected $_db;
	protected $_conf;

	public function __construct($db, $cfg) {
		$this->_db = $db;
		$this->_conf = $cfg;		// save config settings
	}
	
	/**
	 * Resolve method
	 * @param NACRequest $request NACRequest Objcet to resolve and determine what to do
	 * @return NACRequest NACRequest has Allowed set (true/false) and the Assigned VLAN
	 */
	public abstract function Resolve($request);

	/**
	 * Retrieve or Replace existing setting 
	 *   This allows for the setting to be updated during run time vs. a reload/restart
	 * @param Setting Settings Object used for options
	 * @return Setting
	 */
	public function Configuration($cfg = NULL) {
		if ($cfg != NULL) {
			$this->_conf = $cfg;
		}
		return $this->_conf;
	}

}


/**
 * Resolves/Answers VMPS requests V1
 * This class is intended to receive the VMPS requests and respond to it.
 *
 */

class VMPSEngineV1 extends NACResolver {

	public function __construct($db, $cfg) {
		parent::__construct($db, $cfg);
		$this->_db->cacheStatus(false);	// disable caching
	}

	public function Resolve($request) {
		$result=0;         // Deny
		$decided=false;

		$sys = $request->System();
		## Ignore "zero" dummy requests
		if ( $sys->mac == '0000.0000.0000' ) {
			//logit("decide: DENY, ignore mac $mac" );
			$request->Allowed(false);
			return($request);
		}

		$lastVLAN = $request->LastVLAN();
		if ($lastVLAN == NULL) {
			$lastVLAN = new VLAN($this->_db, array("default_name", $lastvlan) );
		}

		$sw = $request->NetworkSwitch();
		$p = $request->Port();

		// Is the system known or unknown?
		if ($sys == NULL) {	// Unknown
			// create new System object
			$sys = new System($this->_db, array("mac" => $mac) );
			// Assign the defaults for Unknown systems
			$sys->vlan = $this->_conf->default_vlan;

			## b) Check for default Vlan for port
			if ($this->_conf->use_port_default_vlan) {
				$result = $p->default_vlan;
				//debug2("decide: ($switch,$port) default vlan is $result");
				# 0 is db default and should not be accepted as valid.
			        # Disabling a port should be done by assigning the '--BLOCK--' vlan.
			        if ($result > 0) {
			        	$decided=true;
			        }
			}
			
			##Virtual machines
			if ( $this->_conf->vm_lan_like_host && $sys->isVM() ) {
				$lastport = $sys->Port;
				if ($lastport != NULL) {
					$now = date('Y-m-d H:i:s');
					$then = $lastport->last_activity;
					$diff = time_diff($then, $now);
					if ($diff <= 7200) {	// if <= 2 hours (in seconds)
						$result = $lastport->last_vlan;
						$decided = true;
					}
				}
			}
			
			## c) Check for default Vlan $default_vlan
			if ($decided == false) {
				$result = $this->_conf->default_vlan; 
				//logit("decide: use default vlan <$this->_conf->default_vlan>");
				$decided = true;
			}
			
			# Check to see there's are port conflicts
			if ( ($this->_conf->detect_hubs) ) {
				/*** Figure this out in the future ****/
				//$result=get_port_status($switch, $port, $mac, $result);
				//$result=get_port_status($switch, $port, $mac, $result, $lastvlan);
				//logit("decide: use $result");
			}
			
		}
		else
		{	// Known System/device
			
			# a) Is this System Enabled?
			if ( !$sys->active() ) {
					//logit("decide: $mac is known but Status=Inactive");
					//debug2("decide: $mac is known but Status=Inactive");
					$result = $this->_conf->vlan_for_killed;
					$decided = true;
					//log2db('info', "decide: $mac is known but Status=Inactive");
			} else if ($sys->status == 0) {
				if ($this->_conf->use_port_default_vlan) {
					$result = $p->default_vlan;
					//debug2("decide: ($switch,$port) default vlan is $result");
					# 0 is db default and should not be accepted as valid.
				        # Disabling a port should be done by assigning the '--BLOCK--' vlan.
				        if ($result > 0) {
				        	$decided=true;
				        }
				}
			
				##Virtual machines
				if ( $this->_conf->vm_lan_like_host && $sys->isVM() ) {
					$lastport = $sys->Port;
					if ($lastport != NULL) {
						$now = date('Y-m-d H:i:s');
						$then = $lastport->last_activity;
						$diff = time_diff($then, $now);
						if ($diff <= 7200) {	// if <= 2 hours (in seconds)
							$result = $lastport->last_vlan;
							$decided = true;
						}
					}
				}
			
				## c) Check for default Vlan $default_vlan
				if ($decided == false) {
					$result = $this->_conf->default_vlan; 
					//logit("decide: use default vlan <$this->_conf->default_vlan>");
					$decided = true;
				}
			} 
			else
			{
				if ($this->_conf->check_for_expired) { 
					# expiration date set?
					if ($sys->expired()) {  
						//debug2("decide: $mac is known but Expired!!");
						$result = $this->_conf->vlan_for_killed;
						$decided = true;
					}
				}
				
				# Check to see there's are port conflicts
				if ( ($this->_conf->detect_hubs) ) {
					/*** Figure this out in the future ****/
					//$result=get_port_status($switch, $port, $mac, $result);
					//$result=get_port_status($switch, $port, $mac, $result, $lastvlan);
					//logit("decide: use $result");
				}
				else
				{
					$result = $sys->vlan;
					$decided = true;
					//logit("decide: using db to assign vlan <$result>");
				}
				
				if ( ($result > 0) && ($this->_conf->vlan_by_switch_location) ) {
					$vlan_id = $sw->DefaultVLAN->vlan_id;
					if ($vlan_id) {
					        //logit("decide: Assigning VLAN by switch location");
					        $result = $vlan_id;
					        $decided = true;
					}
				}
				if ( ($result > 0) && ($this->_conf->check_for_expired) ) {
					if ( $sys->expired()) {
						//logit("decide: $mac is known but Status=Inactive");
						//debug2("decide: $mac is known but Status=Inactive");
						$result = $this->_conf->vlan_for_killed;
						$decided = true;
						//log2db('info', "decide: $mac is known but Status=Inactive");
					}
				}
			
			}
		}

		// Clear changes to avoid update to DB
		$sys->clearChanges();

		// if $result is = then block request else assign vlan and allow.
		if ($result == 0) {
			$targetVLAN = $this->_db->getObject("VLAN", "--NONE--", "default_name");
			$request->Allowed(false);
			
		} else {
			$targetVLAN = $this->_db->getObject("VLAN", $result);
			$request->Allowed(true);
		}
		$request->AssignVLAN($targetVLAN);
		return( $request );
	}
}	


/**
 * Resolves/Answers VMPS requests V2
 * This class is intended to receive the VMPS requests and respond to it.
 *
 */

class VMPSEngineV2 extends NACResolver {

	public function __construct($db, $cfg) {
		parent::__construct($db, $cfg);
		$this->_db->cacheStatus(false);	// disable caching
	}

	public function Resolve($request) {
		$result=0;         // Deny
		$decided=false;

		$sys = $request->System();
		## Ignore "zero" dummy requests
		if ( $sys->mac == '0000.0000.0000' ) {
			//logit("decide: DENY, ignore mac $mac" );
			$request->Allowed(false);
			return($request);
		}

		$lastVLAN = $request->LastVLAN();
		if ($lastVLAN == NULL) {
			$lastVLAN = new VLAN($this->_db, array("default_name", $lastvlan) );
		}

		$sw = $request->NetworkSwitch();
		$p = $request->Port();

		// is the system known or unknown
		if ($sys == NULL) {	// Unknown
			//echo "DEBUG:System is Unknown - creating object\n";
			// create new System object
			$sys = new System($this->_db, array("mac" => $mac) );
			// Assign the defaults for Unknown systems
			$sys->vlan = $this->_conf->default_vlan;

			$check = explode(" ", $this->_conf->unknown_check_order);
			//debug1("Unknown device! Check Order-> $this->_conf->unknown_check_order \n");
		}
		else
		{				// Known
			//echo "DEBUG:System is known\n";
			$check = explode(" ", $this->_conf->known_check_order);
			//debug1("Known device! Check Order-> $this->_conf->known_check_order \n");
		}


		$i=0;
		$check_size = count($check);
		$decided = false;
		while ( ($decided == false) || ($i > $check_size) ) {
			//echo "DEBUG:Checking >>".$check[$i]."<<\n";
			switch ($check[$i]) {

				#Disabled?
				case "disabled":
					if ( $this->_conf->check_for_expired ) {
						if ( !$sys->active()) {
							//logit("decide: $mac is known but Status=Inactive");
							//debug2("decide: $mac is known but Status=Inactive");
							$result = $this->_conf->vlan_for_killed;
							$decided = true;
							//log2db('info', "decide: $mac is known but Status=Inactive");
						}
					}
					break;

				#Expired?
				case "expired":
					if ($this->_conf->check_for_expired) { 
						# expiration date set?
						if ($sys->expired()) {  
							//debug2("decide: $mac is known but Expired!!");
							$result = $this->_conf->vlan_for_killed;
							$decided = true;
						}
					}
					break;

				#Check for switch default
				case "switch":
					$vlan_id = $sw->DefaultVLAN->vlan_id;
					if ($vlan_id)
					{
					        //logit("decide: Assigning VLAN by switch location");
					        $result = $vlan_id;
					        $decided = true;
					}
					break;

				#Check of port default
				case "port":
					if ($this->_conf->use_port_default_vlan) {
						$result = $p->default_vlan;
					        //debug2("decide: ($switch,$port) default vlan is $result");
					        # 0 is db default and should not be accepted as valid.
					        # Disabling a port should be done by assigning the '--BLOCK--' vlan.
					        if ($result > 0) {
					        	$decided=true;
					        }
					}
					break;

				#Use Global default
				case "global":
					$result = $this->_conf->default_vlan; 
					//logit("decide: use default vlan <$this->_conf->default_vlan>");
					$decided = true;
					break;

				#Use vlan assigned in DB
				case "device":
					$result = $sys->vlan;
					$decided = true;
					//logit("decide: using db to assign vlan <$result>");
					break;

				case "redirect": 
					// switch building
					$switch_building = $sw->Location->Building;
					$system_building = $sys->Location->Building;

					//debug1("decide: redirect: switch building = '" . $switch_building->name . "'");
					//debug1("decide: redirect: system building = '" . $system_building->name . "'");
					if( $switch_building != $system_building ) {
						//use switch default vlan
					        $vlan_id = $sw->DefaultVLAN->vid;
					        //debug1("decide: switch default vlan = '" . $vlan_id ."'");
						if ($vlan_id)
					        {
							// ignore certain vlans
							$ignore_vlan = false;
							foreach( $this->_conf->redirect_ignore_vlan as $iv_id ) {
								debug1("decide: ignore vlan = $iv_id");
								// is device assigned vlan to override switch default?
								if( $vlan_id == $iv_id ) {
									$ignore_vlan = true;
									break;
								}
							}
							if ($ignore_vlan == false) {
								//logit("decide: Redirecting VLAN by switch location");
								$result = $vlan_id;
								$decided = true;
							}
					        }
					}
					break;

				case "vms":
				    ##Virtual machines

				    ##Here we ask first if we should check if the device is a virtual machine, and then, if it is, lets assignate the lastvlan of the last
				    ##system active on that port. 
				    if ( $this->_conf->vm_lan_like_host && $sys->isVM() )
				    {
					$lastport = $sys->Port;
					if ($lastport != NULL) {
						$now = date('Y-m-d H:i:s');
						$then = $lastport->last_activity;
						$diff = time_diff($then, $now);
						if ($diff <= 7200) {	// if <= 2 hours (in seconds)
							$result = $lastport->last_vlan;
							$decided = true;
						}
					}
				    }
				break;

				case "hubs":
				    # Check to see there's no port conflicts
				    if ( ($this->_conf->detect_hubs) ) {
				      //$result=get_port_status($switch, $port, $mac, $result);
				      //$result=get_port_status($switch, $port, $mac, $result, $lastvlan);
				      //logit("decide: use $result");
				    }
				break;

				default:
				break;
			        
			} // switch 
			$i += 1;
			//debug2("decide: decided = $decided");
		} // While loop
		  
		//logit("decide: Request for ($switch,$port) $name($mac), $description, vlan=$vlan");
		//logit("decide: $sys->name($sys->r_ip), $description, vlan result=$result on switch $sw->name($switch) $port");
		#debug1("decide: $sys->name, $sys->description, vlan result=$result");

		// Clear changes to avoid update to DB
		$sys->clearChanges();

		// if $result is = then block request else assign vlan and allow.
		//echo "DEBUG:result = ". $result ."\n";
		if ($result == 0) {
			$targetVLAN = $this->_db->getObject("VLAN", "--NONE--", "default_name");
			$request->Allowed(false);
			
		} else {
			$targetVLAN = $this->_db->getObject("VLAN", $result);
			$request->Allowed(true);
		}
		$request->AssignVLAN($targetVLAN);
		return( $request );
	}
}	

class uTimer {
	private $marks;

	public function __construct() {
		$this->_marks = array();
	}

	private function _microtime()
	{
		list($usec, $sec) = explode(" ", microtime());
		return ((float)$usec + (float)$sec);
	}

	public function start() {
		$this->mark("start");
	}

	public function stop() {
		$this->mark("stop");
	}

	public function mark($tag) {
		//echo "mark: $tag\n";
		$this->_marks[$tag] = $this->_microtime();
	}

	public function totaltime() {
		$start = 0;
		$stop = 0;
		$dif = 0;
		$dif = $this->_marks["stop"] - $this->_marks["start"];
		echo "Total time = ". $dif ." seconds\n";
	}

	public function marktimes($from = "start") {
		$dif = 0;
		$prevtime = 0;
		$prevdif = 0;
		$prevmark ="";
		foreach( $this->_marks as $tag => $time ) {
			$dif = $time - $this->_marks[$from];
			echo $tag ." = ". $time ."\tfrom ". $from. " = ". $dif;
			if ($prevtime != 0) {
				$prevdif = $time - $prevtime;
				echo "\t from ". $prevmark ." = ". $prevdif ."\n";
			}
			else {
				echo "\n";
			}
			$prevtime = $time;
			$prevmark = $tag;
		}
		// $this->totaltime();
	}

}

?>

