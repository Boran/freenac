INSERT INTO `config` (`id`, `type`, `name`, `value`, `comment`, `LastChange`, `who`) 
VALUES 
(NULL, 'string', 'postconnect_queue', '/tmp/postconnectqueue', 'File used as IPC for postconnect requests', NOW(), NULL)
(NULL, 'boolean', 'queued_ipc', 'true', 'Indicates how IPC takes place. False=syslog | true=queue', NOW(), NULL)
;
