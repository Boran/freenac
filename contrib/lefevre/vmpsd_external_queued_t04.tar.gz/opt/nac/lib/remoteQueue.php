<?php
/**
 * simple FIFO queue using shared file as shared memory.
 *
 */

//require_once('IPC/SharedMem/File.php');
require_once('File.php');

class remoteQueue extends IPC_SharedMem_File {

	protected $_queue;		// array of queued values

	/**
	 * constructor
	 * @param string $name Name of remote queue
	 */
	public function __construct($name) {
		// call out parent
		parent::__construct($name, array('remove' => false));
		// initialize
		$this->_queue = array();
		
		$this->transaction_start();
		try {
			$x = $this->fetch();
			if( !empty($x) ) {
				$this->_queue = unserialize( $x );
			} else {
				$this->store( serialize($this->_queue) );
			}
			$this->transaction_finish();
		}
		catch(Exception $e) {
			$this->transaction_finish();
			throw $e;
		}
		
	}

	/**
	 * Destructor
	 */
	public function __destruct() {
		parent::__destruct();
	}

	public function _debug() {
		print "-----> debug <-----\n";
		//var_dump($this->_lpid);
		
		var_dump($this);
	}
	

	/**
	 * push object onto remote queue. 
	 * @param object $obj
	 */
	public function push($obj) {
		$this->transaction_start();
		try {
			$this->_queue = unserialize( $this->fetch() );
			$this->_queue[] = $obj;
			$this->store( serialize($this->_queue) );
			$this->transaction_finish();
		}
		catch(Exception $e) {
			$this->transaction_finish();
			throw $e;
		}
	}


	/**
	 * shift object from front of queue
	 * @return object
	 */
	public function shift() {
		$this->transaction_start();
		try {
			$this->_queue = unserialize( $this->fetch() );
			$obj = array_shift($this->_queue);
			$this->store( serialize($this->_queue) );
			$this->transaction_finish();
		}
		catch(Exception $e) {
			$this->transaction_finish();
			throw $e;
		}
		return $obj;
	}

	/**
	 * count objects in the queue
	 * @return int
	 */
	public function count() {
		$this->transaction_start();
		try {
			$this->_queue = unserialize( $this->fetch() );
			$this->transaction_finish();
		}
		catch(Exception $e) {
			$this->transaction_finish();
			throw $e;
		}
		return count($this->_queue);
	}
	 
}


?>
